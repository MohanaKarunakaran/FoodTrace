import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Cattle } from 'src/app/cattle';
import { FarmerComponent } from './farmer/farmer.component';
import { ProcessinghouseComponent } from './processinghouse/processinghouse.component';
//import { Http } from '../../node_modules/@angular/http';
//import { Cattles } from './cattle';


const API_URL = environment.apiUrl;

@Injectable()
export class ApiService {

  constructor(private http: HttpClient) { }

  public getassetid(AssetId): Observable<any> {
   return this.http.get( API_URL + '/farmer?assetid='+AssetId );
          
   }

   public getphdetails(AssetId,userid): Observable<any> {
    return this.http.get( API_URL + '/processingHouse?assetid='+AssetId+'&&userid='+userid );
           
    }
    // will use this.http.get()
    public addfarmer(farmerInfo) {
      var headers=new Headers();
      headers.append("Content-Type","application/json");
      var options={
        headers:headers
      };
      return this.http.post(API_URL + '/farmer',farmerInfo);
    }

    public createOutbound(processinghouse) {
      var headers=new Headers();
      headers.append("Content-Type","application/json");
      var options={
        headers:headers
      };
      return this.http.post(API_URL + '/processingHouse',processinghouse);
    }

   //public addcattle(cattleInfo) {
   //  debugger;
    //  return this.http.post(API_URL + '/cattle',cattleInfo);
   // }
    public getcattledetails(AssetId): Observable<any> {
      return this.http.get( API_URL + '/farmer?assetid='+AssetId );
             
      }
}