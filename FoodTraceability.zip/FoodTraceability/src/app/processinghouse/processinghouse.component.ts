import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { FormBuilder } from'@angular/forms';
import { Router } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiService } from '../api-service.service';

@Component({
  selector: 'app-processinghouse',
  templateUrl: './processinghouse.component.html',
  styleUrls: ['./processinghouse.component.css']
})
export class ProcessinghouseComponent implements OnInit {

  userName:string;
  searchText1:string;
  searchText2:string;
  Lotid: any;
  userid: any;
  AssetId: any;
  certid:any;
  Targetid:any;
  Status:any;
  modal:any;
  NgbdModalContent:any;
  hideAlert:boolean=true;
  myGroup:FormGroup;
  inbound:boolean=true;
  outbound:boolean=false;
  inboundAccept=true;
  inboundReject=true;
  constructor(private router: Router, private apiService:ApiService ) { }

  
  inboundfn() {
    this.inbound=true;
    this.outbound=false;
  }

  outboundfn() {
    this.inbound=false;
    this.outbound=true;
  }
  
  ngOnInit() {
  }

  inboundAcceptfn() {
    this.inboundAccept=false;

  }

  inboundRejectfn() {
    this.inboundReject=false;

  }




  public createOutbound(){
    //debugger;
   this.apiService.createOutbound({"assetid":this.AssetId,"userid":this.userid,"lotid":this.Lotid})
   .subscribe((response) => {
     //debugger;
     if(response){
       this.hideAlert=false;
       // var farmer=response[0];
       // this.AssetId=farmer.assetid;
       // this.userid=farmer.userid;
     }
    }
   );
  }
  
  public getphdetails(AssetId,userid){
    //debugger;
   this.apiService.getphdetails(AssetId,userid)
   .subscribe((response) => {
     if(response){
       var processingHouse=response[0];
       this.AssetId=processingHouse.assetid;
       this.userid=processingHouse.userid;
       this.Status=processingHouse.status;
     }
    }
   );
  }

}

