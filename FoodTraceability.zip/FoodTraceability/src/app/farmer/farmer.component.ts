import { Component, OnInit, Input } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { FormBuilder } from'@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiService } from '../api-service.service';
//import { Observable }from 'rxjs/Observable';
//import { Popup } from 'ng2-opd-popup';

@Component({
  selector: 'app-farmer',
  templateUrl: './farmer.component.html',
  styleUrls: ['./farmer.component.css']
})
export class FarmerComponent implements OnInit {
  @Input() 
  userName:string;
  searchText:string;
  Lotid: any;
  userid: any;
  AssetId: any;
  cattleType: any;
  BirthDate: any;
  Weight: number;
  Location: String;
  hideAlert:boolean=true;
  certid:any;
  Targetid:any;
  Status:any;
  NgbdModalContent:any;
  myGroup:FormGroup;
  hideAlert1:boolean=true;
  hideAlert2:boolean=false;

  constructor(private router: Router, private apiService:ApiService,private route:ActivatedRoute ){
    this.userid=this.route.snapshot.queryParams["userID"];
    }
 //ClickButton(){this.popup.show();}
 public getassetid(AssetId){
   //debugger;
  this.apiService.getassetid(AssetId)
  .subscribe((response) => {
    if(response){
      var farmer=response[0];
      this.AssetId=farmer.assetid;
      this.userid=farmer.userid;
      this.Targetid=farmer.target;
      
    }
   }
  );
 }
 public addfarmer(){
   //debugger;
  this.apiService.addfarmer({"assetid":this.AssetId,"userid":this.userid,"target":this.Targetid,"location":this.Location,
  "weight":this.Weight,"cattletype":this.cattleType,})
  .subscribe((response) => {
    //debugger;
    if(response){
      this.hideAlert=false;
      // var farmer=response[0];
      // this.AssetId=farmer.assetid;
      // this.userid=farmer.userid;
    }
   }
  );
 }
 cattleInit() {
      this.hideAlert1=false;
      this.hideAlert2=true;
      //console.log('success!');
      //this.router.navigate(['./cattle'],{queryParams:{userID:this.userName}})
            }
  cancel() {
      this.hideAlert1=true;
        this.hideAlert2=false;
         }

  ngOnInit() {
    this.myGroup = new FormGroup({
      Lotid:new FormControl(''),
      userid:new FormControl(''),
      AssetId:new FormControl(''),
      status:new FormControl(''),
      Targetid:new FormControl('')})        
            }
  public getcattledetails(AssetId){
             this.hideAlert1=false;
              this.hideAlert2=true;
              debugger;
             this.apiService.getcattledetails(AssetId)
             .subscribe((response) => {
               if(response){
                 var farmer=response[0];
                 this.cattleType=farmer.cattletype;
                 this.Weight=farmer.weight;
                 this.Location = farmer.location;
                 
               }
              }
             );
            }
  // public addcattle(){
  //             debugger;
  //            this.apiService.addcattle({"cattletype":this.cattleType,"weight":this.Weight,
  //            "location":this.Location,"userid":this.userid})
  //            .subscribe((response) => {
  //              //debugger;
  //              if(response){
  //                this.hideAlert=false;
  //                // var farmer=response[0];
  //                // this.AssetId=farmer.assetid;
  //                // this.userid=farmer.userid;
  //              }
  //             }
  //            );
  //           }
   public  pHouse(){
              if(this.Location="")
                  console.log('coming inside PH function')
              this.router.navigate(['./processinghouse']);
            }
}
