import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
//import{ Apiservice } from '@'
import { Http, Headers, RequestOptions } from "@angular/http";
import "rxjs/Rx";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userName:string;
   pasWord:string;
   valid:boolean = true;
   public input: any;
   
   constructor(private router:Router) {
    
    }

  ngOnInit() {
  }
  onSubmit(){
    //console.log('coming inside submit function');
    //if(this.userName == 'userName' && this.pasWord =='pasWord' ){
    //   //console.log('Login was successfull');
    //   if(this.input.username && this.input.password) {
    //     let headers = new Headers({ "content-type": "application/json" });
    //     let options = new RequestOptions({ headers: headers });
    //     this.http.post("http://localhost:3000/login", JSON.stringify(this.input), options)
    //         .map(result => result.json())
    //         .subscribe(result => {
    //             this.router.navigate(["/Farmer"], { "queryParams": result });
    //         });
    // }
    this.router.navigate(['Farmer'],{queryParams:{userID:this.userName}});
    }

}
