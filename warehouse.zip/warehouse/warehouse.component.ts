
import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { FormBuilder } from'@angular/forms';
import { Router,ActivatedRoute } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiService } from '../api-service.service';

@Component({
  selector: 'app-warehouse',
  templateUrl: './warehouse.component.html',
  styleUrls: ['./warehouse.component.css']
})
export class WarehouseComponent implements OnInit {

  userName:string;
  searchText1:string;
  searchText2:string;
  Lotid: any;
  userid: any;
  AssetId: any;
  certid:any;
  Targetid:any;
  Status:any;
  modal:any;
  NgbdModalContent:any;
  hideAlert:boolean=true;
  myGroup:FormGroup;
  inbound:boolean=false;
  outbound:boolean=true;
  inboundAccept=true;
  inboundReject=true;
  moredetails:boolean=true;
  assetCreated:boolean=true;
  assetTransferred:boolean=true;
  packingdate: any;
  useby: any;
  location: any;
  binLocation: any;
  racktype: any;
  deliverby: any;
  intime: any;
  iotdata:any;
  iotRejected:Boolean=true;
  temperature:any;
  startTime:any;
  Sensor:any;
  
 
 

  constructor(private router: Router, private apiService:ApiService,private route:ActivatedRoute ) {
    this.userid=this.route.snapshot.queryParams["userID"]
   }

  
  inboundfn() {
    this.inbound=false;
    this.outbound= true;
    this.moredetails=true;
  }

  outboundfn() {
    this.inbound=true;
    this.outbound= false;
    this.moredetails=true;
  }
  mdetailswh(AssetId){
    this.moredetails=false;
    this.inbound=true;
    this.outbound=true;

   debugger;
   this.apiService.mdetailswh(AssetId)
   .subscribe((response) => {
     if(response){
       var wareHouse=response[0];
       this.AssetId=wareHouse.assetid;
       this.userid=wareHouse.userid;
       //this.Targetid=wareHouse.target;
       this.binLocation=wareHouse.binlocation;
       this.intime=wareHouse.intime;
       this.racktype=wareHouse.racktype;
       this.deliverby=wareHouse.deliverby;
       this.location=wareHouse.location;
     }
    }
   );

  }
  backtoOutbound(){
    this.moredetails=true;
    this.inbound=true;
    this.outbound=false;
  }
  
  ngOnInit() {
  }

  inboundAcceptfn() {
    this.inboundAccept=false;
    this.inboundReject=true;

  }

  inboundRejectfn() {
    this.inboundReject=false;
    this.inboundAccept=true;

  }
  createAsset(){
    this.assetCreated=false;
    this.assetTransferred=true;
  }
  public transferwh(binLocation){
     //debugger;
    if (this.binLocation=="loc1A"){
      this.Sensor="S1";
    }
    else if(this.binLocation=="loc2A"){
      this.Sensor="S2";
    }
    else if(this.binLocation=="loc3A"){
      this.Sensor="S3";
    }
    else if(this.binLocation=="loc4A"){
      this.Sensor="S4";
    }
    else if (this.binLocation=="loc5A"){
      this.Sensor="S5";
    }
    this.apiService.transfer(this.Sensor)
    .subscribe((response) => {
      if(response){
        debugger;
        var iotdata = response[0];
        this.startTime= iotdata.starttime;
       const sTime = new Date(this.startTime)
      const iTime  = new  Date(this.intime)
      if (iTime < sTime) {
        this.iotRejected=false;
          console.log('TransferRejected');
        }
        else{
          this.assetCreated=true;
        this.assetTransferred=false;
        console.log('TrasnferAccepted!');
        }
     }
    }
    );
  }
  
  public createOutbound(){
    //debugger;
   this.apiService.createOutbound({"assetid":this.AssetId,"userid":this.userid,"lotid":this.Lotid})
   .subscribe((response) => {
     //debugger;
     if(response){
       this.hideAlert=false;
      
     }
    }
   );
  }
  
  public getwhdetails(AssetId,userid){
    //debugger;
   this.apiService.getwhdetails(AssetId,userid)
   .subscribe((response) => {
     if(response){
       var processingHouse=response[0];
       this.AssetId=processingHouse.assetid;
       this.userid=processingHouse.userid;
       this.Status=processingHouse.status;
     }
    }
   );
  }


  public getwhdetailsoutbound(AssetId){
   debugger;
   this.apiService.getwhdetailsoutbound(AssetId)
   .subscribe((response) => {
     if(response){
       var wareHouse=response[0];
       this.AssetId=wareHouse.assetid;
       this.userid=wareHouse.userid;
       this.Targetid=wareHouse.target;
       this.binLocation=wareHouse.binlocation;
       this.intime=wareHouse.intime;
       this.racktype=wareHouse.racktype;
       this.deliverby=wareHouse.deliverby;
       this.location=wareHouse.location;
     }
    }
   );
  }

}

